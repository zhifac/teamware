This directory contains a selfcontained demo application for GATE-service (GAS)

How to use it:

In GATE GUI select menu "File --> Restore application from file".
Select gas-demo.xgapp file.

Run "GAS-Test-App".



